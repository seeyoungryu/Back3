package com.example.withdogandcat.domain.shop.entitiy;

public enum ShopType {
    GROOMING,
    HOSPITAL,
    CAFE,
    ETC
}
