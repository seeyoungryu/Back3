package com.example.withdogandcat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WithDogAndCatApplicationTests {

	@Test
	void contextLoads() {
	}
}
